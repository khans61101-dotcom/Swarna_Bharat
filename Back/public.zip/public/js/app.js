const API_URL = 'http://localhost:3000/api';
let cachedUsers = [];
let isLoading = true;

const rolePermissions = {
    Admin: [
        "overviewTab",
        "usersTab",
        "newsTab",
        "eventsTab",
        "galleryTab",
        "blogsTab",
        "enquiriesTab",
        "profileTab",
        "settingsTab"
    ],
    Agent: [
       
        "usersTab",
        "newsTab",
        "eventsTab",
        "galleryTab",
        "blogsTab",
        "enquiriesTab",
        "profileTab",
      
    ],
    User: [
        "usersTab",
        "overviewTab",
        "galleryTab", 
        "blogsTab",
        "profileTab"
    ],
    Member: [
        "overviewTab",
        "newsTab",
        "eventsTab",
        "galleryTab",
        "blogsTab",
        "profileTab"
    ]
};             




function applyTheme(theme) {
    const body = document.body;
    const isDark = theme === 'dark';

    if (isDark) {
        body.classList.add('dark-theme', 'dark-mode');
        body.classList.remove('light-theme', 'light-mode');
        localStorage.setItem('theme', 'dark');
    } else {
        body.classList.add('light-theme', 'light-mode');
        body.classList.remove('dark-theme', 'dark-mode');
        localStorage.setItem('theme', 'light');
    }

    const themeThumb = document.getElementById('themeThumb');
    if (themeThumb) {
        if (isDark) {
            themeThumb.style.transform = 'translateX(18px)';
            themeThumb.textContent = '🌙';
        } else {
            themeThumb.style.transform = 'translateX(0px)';
            themeThumb.textContent = '☀️';
        }
    }

    const themeToggle = document.getElementById('themeToggle');
    if (themeToggle) {
        if (isDark) {
            themeToggle.classList.add('dark');
            themeToggle.classList.remove('light');
        } else {
            themeToggle.classList.add('light');
            themeToggle.classList.remove('dark');
        }
    }

    const themeSelect = document.getElementById('settingTheme');
    if (themeSelect) {
        themeSelect.value = isDark ? 'dark' : 'light';
    }
}

function toggleTheme() {
    const currentTheme = localStorage.getItem('theme') || (document.body.classList.contains('dark-theme') || document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    applyTheme(newTheme);
}

window.applyTheme = applyTheme;
window.toggleTheme = toggleTheme;   
// ==============================
// LOADING MANAGEMENT
// ==============================
function showLoading(message = 'Loading...') {
    let overlay = document.getElementById('loadingOverlay');
    if (!overlay) {
        overlay = document.createElement('div');
        overlay.id = 'loadingOverlay';
        overlay.style.cssText = `
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(15, 23, 42, 0.85);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 99999;
            flex-direction: column;
            gap: 1.5rem;
            transition: opacity 0.3s ease;
        `;
        overlay.innerHTML = `
            <div style="
                width: 60px;
                height: 60px;
                border: 4px solid rgba(255,255,255,0.1);
                border-top: 4px solid #3b82f6;
                border-radius: 50%;
                animation: spin 1s cubic-bezier(0.68, -0.55, 0.265, 1.55) infinite;
            "></div>
            <p id="loadingMessage" style="color: white; font-size: 1.1rem; font-weight: 500; margin: 0;">${message}</p>
            <style>
                @keyframes spin {
                    0% { transform: rotate(0deg); }
                    100% { transform: rotate(360deg); }
                }
                @keyframes pulse {
                    0%, 100% { opacity: 1; }
                    50% { opacity: 0.5; }
                }
            </style>
        `;
        document.body.appendChild(overlay);
    } else {
        document.getElementById('loadingMessage').textContent = message;
        overlay.style.display = 'flex';
    }
    isLoading = true;
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.opacity = '0';
        setTimeout(() => {
            overlay.style.display = 'none';
            overlay.style.opacity = '1';
        }, 300);
    }
    isLoading = false;
}

function updateLoadingMessage(message) {
    const msgEl = document.getElementById('loadingMessage');
    if (msgEl) {
        msgEl.textContent = message;
    }
}

// ==============================
// AUTHENTICATION
// ==============================
function checkAuth() {
    showLoading('Checking authentication...');
    
    const token = localStorage.getItem('token');
    const userStr = localStorage.getItem('user');
    
    const isLoginPage = window.location.pathname.endsWith('index.html') || window.location.pathname === '/';
    const isDashboardPage = window.location.pathname.endsWith('dashboard.html');

    const isAddPage = !isLoginPage && !isDashboardPage;

    setTimeout(() => {
        try {
            if (!token && isDashboardPage) {
                updateLoadingMessage('Redirecting to login...');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 500);
                return;
            } else if (!token && isAddPage) {
                updateLoadingMessage('Please login first...');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 500);
                return;
            } else if (token && isLoginPage) {
                updateLoadingMessage('Redirecting to dashboard...');
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 500);
                return;
            }

            if (userStr && isDashboardPage) {
                try {
                    const user = JSON.parse(userStr);
                    if (!user || !user.role) {
                        throw new Error('Invalid user data');
                    }
                    updateLoadingMessage('Setting up dashboard...');
                    setTimeout(() => {
                        setupDashboard(user);
                        hideLoading();
                    }, 300);
                } catch (e) {
                    console.error('Error parsing user data:', e);
                    localStorage.removeItem('user');
                    localStorage.removeItem('token');
                    updateLoadingMessage('Session expired. Redirecting...');
                    setTimeout(() => {
                        window.location.href = 'index.html';
                    }, 500);
                }
            } else if (isDashboardPage) {
                updateLoadingMessage('No session found. Redirecting...');
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 500);
            } else {
                // Standalone add page with valid token — setup form listeners
                setupFormListeners();
                applyTheme(localStorage.getItem('theme') || 'light');
                hideLoading();
            }
        } catch (error) {
            console.error('Auth check error:', error);
            hideLoading();
        }
    }, 200);
}

function logout() {
    showLoading('Logging out...');
    setTimeout(() => {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = 'index.html';
    }, 300);
}

// ==============================
// PERMISSIONS
// ==============================
function applyRolePermissions(role) {
    console.log("Logged in Role:", role);
    const allowedTabs = rolePermissions[role] || [];
    console.log("Allowed Tabs:", allowedTabs);

    document.querySelectorAll(".sidebar-item").forEach(item => {
        const tab = item.dataset.tab;
        if (allowedTabs.includes(tab)) {
            item.style.display = "flex";
        } else {
            item.style.display = "none";
        }
    });
}

// ==============================
// DASHBOARD SETUP
// ==============================
function setupDashboard(user) {
    if (!user || !user.role) {
        console.error('Invalid user data in setupDashboard');
        window.location.href = 'index.html';
        return;
    }

    // Update user info
    const userNameEl = document.getElementById('userName');
    const userRoleEl = document.getElementById('userRole');
    const headerUserEl = document.getElementById('headerUser');
    
    if (userNameEl) userNameEl.textContent = user.name || 'User';
    if (userRoleEl) userRoleEl.textContent = user.role || 'User';
    if (headerUserEl) headerUserEl.textContent = `👋 ${user.name || 'User'}  ·  ${user.role || 'User'}`;

    // Setup role select
    const targetRoleSelect = document.getElementById('targetRole');
    if (targetRoleSelect) {
        if (user.role === 'Admin') {
            targetRoleSelect.innerHTML = `
                <option value="Agent">Agent</option>
                <option value="User">User</option>
                <option value="Member">Member</option>
            `;
        } else if (user.role === 'Agent') {
            targetRoleSelect.innerHTML = `
                <option value="Agent">Sub-Agent</option>
                <option value="User">User</option>
            `;
        } else {
            targetRoleSelect.innerHTML = `
                <option value="Member">Member</option>
            `;
        }
    }

    // Apply role permissions
    applyRolePermissions(user.role);

    // Setup form listeners
    setupFormListeners();

    // Load initial data
    loadOverviewStats();

    // Open first tab
    openDefaultTab(user);
}

function openDefaultTab(user) {
    const firstTab = rolePermissions[user.role]?.[0];
    
    if (firstTab) {
        document.querySelectorAll(".tab-content").forEach(tab => {
            tab.classList.remove("active");
        });

        document.querySelectorAll(".sidebar-item").forEach(item => {
            item.classList.remove("active");
            if (item.dataset.tab === firstTab) {
                item.classList.add("active");
            }
        });

        const firstContent = document.getElementById(firstTab);
        if (firstContent) {
            firstContent.classList.add("active");
        }

        // Load initial tab content
        switch (firstTab) {
            case "overviewTab":
                loadOverviewStats();
                break;
            case "usersTab":
                loadUsers();
                break;
            case "newsTab":
                loadNews();
                break;
            case "eventsTab":
                loadEvents();
                break;
            case "galleryTab":
                loadGallery();
                break;
            case "blogsTab":
                loadBlogs();
                break;
            case "enquiriesTab":
                loadEnquiries();
                break;
            case "profileTab":
                loadMyProfile();
                break;
            default:
                break;
        }
    }
}

// ==============================
// TAB SWITCHING
// ==============================
function switchTab(tabId, element) {
    const user = JSON.parse(localStorage.getItem("user"));
    const allowedTabs = rolePermissions[user.role] || [];

    if (!allowedTabs.includes(tabId)) {
        alert("Access Denied");
        return;
    }

    document.querySelectorAll('.tab-content').forEach(tab => tab.classList.remove('active'));
    document.querySelectorAll('.sidebar-item').forEach(item => item.classList.remove('active'));

    document.getElementById(tabId).classList.add('active');
    element.classList.add('active');

    // Load tab content
    showLoading(`Loading ${tabId.replace('Tab', '')}...`);
    setTimeout(() => {
        switch (tabId) {
            case 'overviewTab':
                loadOverviewStats();
                break;
            case 'usersTab':
                loadUsers();
                break;
            case 'newsTab':
                loadNews();
                break;
            case 'eventsTab':
                loadEvents();
                break;
            case 'galleryTab':
                loadGallery();
                break;
            case 'blogsTab':
                loadBlogs();
                break;
            case 'enquiriesTab':
                loadEnquiries();
                break;
            case 'profileTab':
                loadMyProfile();
                break;
            default:
                break;
        }
        hideLoading();
    }, 300);
}

// ==============================
// OVERVIEW STATS
// ==============================
async function loadOverviewStats() {
    try {
        const tokenHeader = { 'Authorization': `Bearer ${localStorage.getItem('token')}` };
        
        const [uRes, nRes, eRes, gRes, bRes, enqRes] = await Promise.all([
            fetch(`${API_URL}/users`, { headers: tokenHeader }).catch(() => null),
            fetch(`${API_URL}/news`).catch(() => null),
            fetch(`${API_URL}/events`).catch(() => null),
            fetch(`${API_URL}/gallery`).catch(() => null),
            fetch(`${API_URL}/blogs`).catch(() => null),
            fetch(`${API_URL}/enquiries`, { headers: tokenHeader }).catch(() => null)
        ]);

        if (uRes && uRes.ok) {
            const uData = await uRes.json();
            const countEl = document.getElementById('countUsers');
            if (countEl) countEl.textContent = uData.length || 0;
        }
        if (nRes && nRes.ok) {
            const nData = await nRes.json();
            const countEl = document.getElementById('countNews');
            if (countEl) countEl.textContent = nData.length || 0;
        }
        if (eRes && eRes.ok) {
            const eData = await eRes.json();
            const countEl = document.getElementById('countEvents');
            if (countEl) countEl.textContent = eData.length || 0;
        }
        if (gRes && gRes.ok) {
            const gData = await gRes.json();
            const countEl = document.getElementById('countGallery');
            if (countEl) countEl.textContent = gData.length || 0;
        }
        if (bRes && bRes.ok) {
            const bData = await bRes.json();
            const countEl = document.getElementById('countBlogs');
            if (countEl) countEl.textContent = bData.length || 0;
        }
        if (enqRes && enqRes.ok) {
            const enqData = await enqRes.json();
            const pendingCount = enqData.filter(item => item.status === 'Pending').length;
            const countEl = document.getElementById('countEnquiries');
            if (countEl) countEl.textContent = pendingCount || 0;
        }
    } catch (err) {
        console.error('Error loading stats:', err);
    }
}

// ==============================
// LOGIN
// ==============================
if (document.getElementById('loginForm')) {
    document.getElementById('loginForm').addEventListener('submit', async (e) => {
        e.preventDefault();

        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const errorDiv = document.getElementById('loginError');

        showLoading('Logging in...');

        try {
            const response = await fetch(`${API_URL}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await response.json();

            if (response.ok) {
                localStorage.setItem('token', data.accessToken);
                localStorage.setItem('user', JSON.stringify({
                    id: data.id,
                    name: data.name,
                    email: data.email,
                    role: data.role
                }));

                updateLoadingMessage('Login successful! Redirecting...');
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 500);
            } else {
                hideLoading();
                errorDiv.textContent = data.error || 'Login failed';
            }
        } catch (err) {
            hideLoading();
            errorDiv.textContent = 'Server error. Please try again.';
        }
    });
}

// ==============================
// FILE UPLOAD
// ==============================
async function uploadFile(fileInput) {
    if (!fileInput || !fileInput.files || fileInput.files.length === 0) return '';
    
    showLoading('Uploading file...');
    
    try {
        const formData = new FormData();
        formData.append('image', fileInput.files[0]);

        const res = await fetch(`${API_URL}/upload`, {
            method: 'POST',
            body: formData
        });
        const data = await res.json();
        hideLoading();
        return data.imageUrl || '';
    } catch (error) {
        hideLoading();
        console.error('Upload error:', error);
        return '';
    }
}

// ==============================
// FORM LISTENERS
// ==============================
function setupFormListeners() {
    // Create User Form
    const userForm = document.getElementById('createUserForm');
    if (userForm) {
        userForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading('Creating user...');
            
            const body = {
                name: document.getElementById('newName').value,
                email: document.getElementById('newEmail').value,
                password: document.getElementById('newPassword').value,
                phone: document.getElementById('newPhone').value,
                dob: document.getElementById('newDob').value,
                address: document.getElementById('newAddress').value,
                city: document.getElementById('newCity').value,
                state: document.getElementById('newState').value,
                pincode: document.getElementById('newPincode').value,
                bank_name: document.getElementById('newBankName').value,
                account_no: document.getElementById('newAccountNo').value,
                ifsc_code: document.getElementById('newIfscCode').value,
                upi_id: document.getElementById('newUpiId').value,
                target_role: document.getElementById('targetRole') ? document.getElementById('targetRole').value : null
            };

            const errorDiv = document.getElementById('createError');
            try {
                const res = await fetch(`${API_URL}/users`, {
                    method: 'POST',
                    headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': `Bearer ${localStorage.getItem('token')}` 
                    },
                    body: JSON.stringify(body)
                });
                const data = await res.json();
                hideLoading();
                
                if (res.ok) {
                    errorDiv.style.color = '#16A34A';
                    errorDiv.textContent = '✅ ' + (data.message || 'User created successfully!');
                    userForm.reset();
                    loadUsers();
                } else {
                    errorDiv.style.color = '#DC2626';
                    errorDiv.textContent = '❌ ' + (data.error || 'Failed to create user');
                }
            } catch(err) {
                hideLoading();
                errorDiv.textContent = '❌ Error creating account';
                console.error(err);
            }
        });
    }

    // News Form
    const newsForm = document.getElementById('createNewsForm');
    if (newsForm) {
        newsForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading('Creating news...');
            
            const newsImgFile = document.getElementById('newsImage');
            const imageUrl = await uploadFile(newsImgFile);

            const body = {
                title: document.getElementById('newsTitle').value,
                title_hi: document.getElementById('newsTitleHi').value,
                date: document.getElementById('newsDate').value,
                category: document.getElementById('newsCategory').value,
                category_hi: document.getElementById('newsCategoryHi').value,
                snippet: document.getElementById('newsSnippet').value,
                snippet_hi: document.getElementById('newsSnippetHi').value,
                image: imageUrl,
            };
            await sendPost(`${API_URL}/news`, body, newsForm, loadNews, 'newsError');
        });
    }

    // Events Form
    const eventForm = document.getElementById('createEventForm');
    if (eventForm) {
        eventForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading('Creating event...');
            
            const eventImgFile = document.getElementById('eventImage');
            const imageUrl = await uploadFile(eventImgFile);

            const body = {
                day: document.getElementById('eventDay').value,
                month: document.getElementById('eventMonth').value,
                year: document.getElementById('eventYear').value,
                title: document.getElementById('eventTitle').value,
                title_hi: document.getElementById('eventTitleHi').value,
                location: document.getElementById('eventLocation').value,
                location_hi: document.getElementById('eventLocationHi').value,
                category: document.getElementById('eventCategory').value,
                category_hi: document.getElementById('eventCategoryHi').value,
                desc: document.getElementById('eventDesc').value,
                desc_hi: document.getElementById('eventDescHi').value,
                image: imageUrl,
            };
            await sendPost(`${API_URL}/events`, body, eventForm, loadEvents, 'eventError');
        });
    }

    // Gallery Form
    const galleryForm = document.getElementById('createGalleryForm');
    if (galleryForm) {
        galleryForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading('Adding to gallery...');
            
            const galleryFile = document.getElementById('gallerySrc');
            const imageUrl = await uploadFile(galleryFile);

            const body = {
                src: imageUrl,
                title: document.getElementById('galleryTitle').value,
                title_hi: document.getElementById('galleryTitleHi').value,
                category: document.getElementById('galleryCategory').value,
                category_hi: document.getElementById('galleryCategoryHi').value,
            };
            await sendPost(`${API_URL}/gallery`, body, galleryForm, loadGallery, 'galleryError');
        });
    }

    // Blog Form
    const blogForm = document.getElementById('createBlogForm');
    if (blogForm) {
        blogForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading('Creating blog...');
            
            const blogImgFile = document.getElementById('blogImage');
            const imageUrl = await uploadFile(blogImgFile);

            const body = {
                title: document.getElementById('blogTitle').value,
                title_hi: document.getElementById('blogTitleHi').value,
                author: document.getElementById('blogAuthor').value,
                content: document.getElementById('blogContent').value,
                content_hi: document.getElementById('blogContentHi').value,
                image: imageUrl,
            };
            await sendPost(`${API_URL}/blogs`, body, blogForm, loadBlogs, 'blogError');
        });
    }

    // Update Profile Form
    const profileForm = document.getElementById('updateProfileForm');
    if (profileForm) {
        profileForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            showLoading('Updating profile...');
            
            const msgDiv = document.getElementById('profileMsg');
            const body = {
                name: document.getElementById('myProfileName').value,
                phone: document.getElementById('myProfilePhone').value,
                dob: document.getElementById('myProfileDob').value,
                address: document.getElementById('myProfileAddress').value,
                city: document.getElementById('myProfileCity').value,
                state: document.getElementById('myProfileState').value,
                pincode: document.getElementById('myProfilePincode').value,
                bank_name: document.getElementById('myProfileBankName').value,
                account_no: document.getElementById('myProfileAccountNo').value,
                ifsc_code: document.getElementById('myProfileIfscCode').value,
                upi_id: document.getElementById('myProfileUpiId').value,
            };

            try {
                const res = await fetch(`${API_URL}/auth/profile`, {
                    method: 'PUT',
                    headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': `Bearer ${localStorage.getItem('token')}` 
                    },
                    body: JSON.stringify(body)
                });
                const data = await res.json();
                hideLoading();
                
                if (res.ok) {
                    msgDiv.style.color = '#16A34A';
                    msgDiv.textContent = '✅ Profile updated successfully!';
                    // Update user name in header
                    const user = JSON.parse(localStorage.getItem('user'));
                    user.name = body.name;
                    localStorage.setItem('user', JSON.stringify(user));
                    document.getElementById('userName').textContent = body.name;
                    document.getElementById('headerUser').textContent = `👋 ${body.name}  ·  ${user.role}`;
                } else {
                    msgDiv.style.color = '#DC2626';
                    msgDiv.textContent = '❌ ' + (data.error || 'Failed to update profile');
                }
            } catch (err) {
                hideLoading();
                msgDiv.textContent = '❌ Error updating profile';
                console.error(err);
            }
        });
    }

    // Change Password Form
    const passForm = document.getElementById('changePasswordForm');
    if (passForm) {
        passForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            const msgDiv = document.getElementById('passwordMsg');
            const currPass = document.getElementById('currPass').value;
            const newPass = document.getElementById('newPass').value;
            const confirmPass = document.getElementById('confirmPass').value;

            if (newPass !== confirmPass) {
                msgDiv.style.color = '#DC2626';
                msgDiv.textContent = '❌ New passwords do not match';
                return;
            }

            showLoading('Changing password...');

            try {
                const res = await fetch(`${API_URL}/auth/change-password`, {
                    method: 'PUT',
                    headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': `Bearer ${localStorage.getItem('token')}` 
                    },
                    body: JSON.stringify({ currentPassword: currPass, newPassword: newPass })
                });
                const data = await res.json();
                hideLoading();
                
                if (res.ok) {
                    msgDiv.style.color = '#16A34A';
                    msgDiv.textContent = '✅ Password changed successfully!';
                    passForm.reset();
                } else {
                    msgDiv.style.color = '#DC2626';
                    msgDiv.textContent = '❌ ' + (data.error || 'Failed to change password');
                }
            } catch (err) {
                hideLoading();
                msgDiv.textContent = '❌ Error changing password';
                console.error(err);
            }
        });
    }

    // System Settings Form
    const settingsForm = document.getElementById('settingsForm');
    if (settingsForm) {
        settingsForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const msgDiv = document.getElementById('settingsMsg');
            const theme = document.getElementById('settingTheme').value;
            
           if(theme==="dark"){
    document.body.classList.add("dark-theme");
    document.body.classList.remove("light-theme");
}else{
    document.body.classList.add("light-theme");
    document.body.classList.remove("dark-theme");
}

localStorage.setItem("theme",theme);
            msgDiv.style.color = '#16A34A';
            msgDiv.textContent = '✅ Settings saved successfully!';
            
            setTimeout(() => {
                msgDiv.textContent = '';
            }, 3000);
        });
    }
}

// ==============================
// SEND POST HELPER
// ==============================
async function sendPost(url, body, form, reloadFn, errorId) {
    const errDiv = document.getElementById(errorId);
    try {
        const res = await fetch(url, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json', 
                'Authorization': `Bearer ${localStorage.getItem('token')}` 
            },
            body: JSON.stringify(body)
        });
        const data = await res.json();
        hideLoading();
        
        if (res.ok) {
            errDiv.style.color = '#16A34A';
            errDiv.textContent = '✅ Added successfully! Redirecting...';
            form.reset();
            // If on a standalone add-*.html page, go back to dashboard
            const isStandalonePage = !window.location.pathname.endsWith('dashboard.html') && 
                                     !window.location.pathname.endsWith('index.html');
            if (isStandalonePage) {
                setTimeout(() => {
                    window.location.href = 'dashboard.html';
                }, 1000);
            } else {
                reloadFn();
            }
        } else {
            errDiv.style.color = '#DC2626';
            errDiv.textContent = '❌ ' + (data.error || 'Failed');
        }
    } catch (err) {
        hideLoading();
        errDiv.textContent = '❌ Error';
        console.error(err);
    }
}

// ==============================
// LOAD FUNCTIONS
// ==============================
async function loadUsers() {
    try {
        const tbody = document.querySelector('#usersTable tbody');
        if (!tbody) return;
        
        const res = await fetch(`${API_URL}/users`, { 
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` } 
        });
        
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const data = await res.json();
        cachedUsers = data;
        
        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#64748B;padding:2rem;">No users found</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.map(u => {
            let badgeBg = '#0369A1';
            if (u.role_name === 'Admin') badgeBg = '#2563EB';
            else if (u.role_name === 'Agent') badgeBg = '#EA580C';
            else if (u.role_name === 'Member') badgeBg = '#7C3AED';

            return `
                <tr>
                    <td><strong>${u.name || 'N/A'}</strong><br><small class="text-muted">${u.email || 'N/A'}</small></td>
                    <td><span class="role-badge" style="background:${badgeBg};color:white;padding:4px 12px;border-radius:20px;font-size:0.8rem;">${u.role_name || 'User'}</span></td>
                    <td>${u.phone || '-'}</td>
                    <td>${u.created_by_name || 'System / Admin'}</td>
                    <td>
                        <button class="btn-sm btn-info" onclick="openDownlineModal(${u.id}, '${(u.name || '').replace(/'/g, "\\'")}')" style="background:#0F172A;color:white;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;">
                            ${u.downline_count || 0} Members 🔍
                        </button>
                    </td>
                    <td>
                        <button class="btn-sm btn-info" onclick="openProfileModal(${u.id})" style="background:#2563EB;color:white;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;">
                            📋 Details
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        console.error('Error loading users:', error);
        const tbody = document.querySelector('#usersTable tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#DC2626;padding:2rem;">❌ Failed to load users</td></tr>';
        }
    }
}

async function loadNews() {
    try {
        const tbody = document.querySelector('#newsTable tbody');
        if (!tbody) return;
        
        const res = await fetch(`${API_URL}/news`);
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const data = await res.json();
        
        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#64748B;padding:2rem;">No news found</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.map(n => `
            <tr>
                <td><strong>${n.title || 'N/A'}</strong></td>
                <td>${n.category || '-'}</td>
                <td>${n.date || '-'}</td>
                <td>
                    <button class="logout-btn btn-danger" onclick="deleteItem('/news/${n.id}', loadNews)" style="background:#DC2626;color:white;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;">
                        🗑️ Delete
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading news:', error);
        const tbody = document.querySelector('#newsTable tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#DC2626;padding:2rem;">❌ Failed to load news</td></tr>';
        }
    }
}

async function loadEvents() {
    try {
        const tbody = document.querySelector('#eventsTable tbody');
        if (!tbody) return;
        
        const res = await fetch(`${API_URL}/events`);
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const data = await res.json();
        
        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#64748B;padding:2rem;">No events found</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.map(e => `
            <tr>
                <td><strong>${e.title || 'N/A'}</strong></td>
                <td>${e.day || ''} ${e.month || ''} ${e.year || ''}</td>
                <td>${e.location || '-'}</td>
                <td>
                    <button class="logout-btn btn-danger" onclick="deleteItem('/events/${e.id}', loadEvents)" style="background:#DC2626;color:white;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;">
                        🗑️ Delete
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading events:', error);
        const tbody = document.querySelector('#eventsTable tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#DC2626;padding:2rem;">❌ Failed to load events</td></tr>';
        }
    }
}

async function loadGallery() {
    try {
        const tbody = document.querySelector('#galleryTable tbody');
        if (!tbody) return;
        
        const res = await fetch(`${API_URL}/gallery`);
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const data = await res.json();
        
        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#64748B;padding:2rem;">No gallery items found</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.map(g => `
            <tr>
                <td>
                    <img src="${g.src || ''}" style="width: 50px; height: 35px; object-fit: cover; border-radius: 4px;" onerror="this.src='data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 width=%2250%22 height=%2235%22%3E%3Crect width=%2250%22 height=%2235%22 fill=%22%23e2e8f0%22/%3E%3C/svg%3E'">
                </td>
                <td>${g.title || '-'}</td>
                <td>${g.category || '-'}</td>
                <td>
                    <button class="logout-btn btn-danger" onclick="deleteItem('/gallery/${g.id}', loadGallery)" style="background:#DC2626;color:white;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;">
                        🗑️ Delete
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading gallery:', error);
        const tbody = document.querySelector('#galleryTable tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#DC2626;padding:2rem;">❌ Failed to load gallery</td></tr>';
        }
    }
}

async function loadBlogs() {
    try {
        const tbody = document.querySelector('#blogsTable tbody');
        if (!tbody) return;
        
        const res = await fetch(`${API_URL}/blogs`);
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const data = await res.json();
        
        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#64748B;padding:2rem;">No blogs found</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.map(b => `
            <tr>
                <td><strong>${b.title || 'N/A'}</strong></td>
                <td>${b.author || '-'}</td>
                <td>${b.created_at ? new Date(b.created_at).toLocaleDateString() : '-'}</td>
                <td>
                    <button class="logout-btn btn-danger" onclick="deleteItem('/blogs/${b.id}', loadBlogs)" style="background:#DC2626;color:white;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;">
                        🗑️ Delete
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading blogs:', error);
        const tbody = document.querySelector('#blogsTable tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#DC2626;padding:2rem;">❌ Failed to load blogs</td></tr>';
        }
    }
}

async function loadEnquiries() {
    try {
        const tbody = document.querySelector('#enquiriesTable tbody');
        if (!tbody) return;
        
        const res = await fetch(`${API_URL}/enquiries`, { 
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` } 
        });
        
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const data = await res.json();
        
        if (data.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#64748B;padding:2rem;">No enquiries found</td></tr>';
            return;
        }
        
        tbody.innerHTML = data.map(e => `
            <tr>
                <td><strong>${e.name || 'N/A'}</strong></td>
                <td>${e.email || 'N/A'}<br><small style="color:#64748B;">${e.phone || ''}</small></td>
                <td>${e.subject || '-'}</td>
                <td style="max-width:200px;word-wrap:break-word;">${e.message || '-'}</td>
                <td>
                    <span style="background:${e.status === 'Pending' ? '#F59E0B' : '#10B981'};color:white;padding:2px 10px;border-radius:12px;font-size:0.8rem;">
                        ${e.status || 'Pending'}
                    </span>
                </td>
                <td>
                    <button onclick="updateEnquiryStatus(${e.id}, '${e.status === 'Pending' ? 'Resolved' : 'Pending'}')" style="background:#0F172A;color:white;border:none;padding:4px 12px;border-radius:4px;cursor:pointer;">
                        ${e.status === 'Pending' ? '✅ Resolve' : '🔄 Reopen'}
                    </button>
                </td>
            </tr>
        `).join('');
    } catch (error) {
        console.error('Error loading enquiries:', error);
        const tbody = document.querySelector('#enquiriesTable tbody');
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:#DC2626;padding:2rem;">❌ Failed to load enquiries</td></tr>';
        }
    }
}

async function updateEnquiryStatus(id, newStatus) {
    showLoading('Updating status...');
    try {
        await fetch(`${API_URL}/enquiries/${id}`, {
            method: 'PUT',
            headers: { 
                'Content-Type': 'application/json', 
                'Authorization': `Bearer ${localStorage.getItem('token')}` 
            },
            body: JSON.stringify({ status: newStatus })
        });
        hideLoading();
        loadEnquiries();
    } catch (error) {
        hideLoading();
        console.error('Error updating enquiry status:', error);
        alert('Failed to update status');
    }
}

async function loadMyProfile() {
    try {
        const res = await fetch(`${API_URL}/auth/me`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const u = await res.json();
        
        document.getElementById('myProfileName').value = u.name || '';
        document.getElementById('myProfileEmail').value = u.email || '';
        document.getElementById('myProfilePhone').value = u.phone || '';
        document.getElementById('myProfileDob').value = u.dob || '';
        document.getElementById('myProfileAddress').value = u.address || '';
        document.getElementById('myProfileCity').value = u.city || '';
        document.getElementById('myProfileState').value = u.state || '';
        document.getElementById('myProfilePincode').value = u.pincode || '';
        document.getElementById('myProfileBankName').value = u.bank_name || '';
        document.getElementById('myProfileAccountNo').value = u.account_no || '';
        document.getElementById('myProfileIfscCode').value = u.ifsc_code || '';
        document.getElementById('myProfileUpiId').value = u.upi_id || '';
    } catch (error) {
        console.error('Error fetching profile:', error);
    }
}

// ==============================
// MODAL FUNCTIONS
// ==============================
async function openDownlineModal(parentId, parentName) {
    const modal = document.getElementById('detailsModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');

    modalTitle.textContent = `👥 Downline Members under: ${parentName}`;
    modalBody.innerHTML = '<p style="text-align:center;color:#64748B;">Loading downline list...</p>';
    modal.classList.add('active');

    try {
        const res = await fetch(`${API_URL}/users/${parentId}/downline`, {
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        
        if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
        
        const members = await res.json();

        if (members.length === 0) {
            modalBody.innerHTML = '<p style="text-align:center;color:#64748B;padding:2rem;">No members registered under this account yet.</p>';
            return;
        }

        modalBody.innerHTML = `
            <div style="overflow-x:auto;">
                <table style="width:100%;border-collapse:collapse;font-size:0.9rem;">
                    <thead>
                        <tr style="background:#F1F5F9;">
                            <th style="padding:8px 12px;text-align:left;">Name</th>
                            <th style="padding:8px 12px;text-align:left;">Role</th>
                            <th style="padding:8px 12px;text-align:left;">Phone</th>
                            <th style="padding:8px 12px;text-align:left;">Created Date</th>
                            <th style="padding:8px 12px;text-align:left;">Sub-Downline</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${members.map(m => `
                            <tr style="border-bottom:1px solid #E2E8F0;">
                                <td style="padding:8px 12px;"><strong>${m.name || 'N/A'}</strong><br><small style="color:#64748B;">${m.email || 'N/A'}</small></td>
                                <td style="padding:8px 12px;"><span style="background:#7C3AED;color:white;padding:2px 10px;border-radius:12px;font-size:0.8rem;">${m.role_name || 'User'}</span></td>
                                <td style="padding:8px 12px;">${m.phone || '-'}</td>
                                <td style="padding:8px 12px;">${m.created_at ? new Date(m.created_at).toLocaleDateString() : '-'}</td>
                                <td style="padding:8px 12px;"><strong>${m.downline_count || 0}</strong></td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    } catch (error) {
        modalBody.innerHTML = '<p style="text-align:center;color:#DC2626;padding:2rem;">❌ Failed to load downline list.</p>';
        console.error('Error loading downline:', error);
    }
}

function openProfileModal(userId) {
    const u = cachedUsers.find(item => item.id === userId);
    if (!u) {
        alert('User not found');
        return;
    }

    const modal = document.getElementById('detailsModal');
    const modalTitle = document.getElementById('modalTitle');
    const modalBody = document.getElementById('modalBody');

    modalTitle.textContent = `📋 Profile & Payment Details: ${u.name || 'User'}`;
    modalBody.innerHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; font-size: 0.95rem;">
            <div style="background:#F8FAFC; padding: 1.5rem; border-radius: 8px; border:1px solid #E2E8F0;">
                <h4 style="color:#1E293B; margin-bottom: 0.75rem; border-bottom: 1px solid #CBD5E1; padding-bottom: 8px;">👤 Personal Info</h4>
                <p><strong>Name:</strong> ${u.name || 'N/A'}</p>
                <p><strong>Email:</strong> ${u.email || 'N/A'}</p>
                <p><strong>Phone:</strong> ${u.phone || 'N/A'}</p>
                <p><strong>DOB:</strong> ${u.dob || 'N/A'}</p>
                <p><strong>Role:</strong> <span style="background:#2563EB;color:white;padding:2px 10px;border-radius:12px;font-size:0.8rem;">${u.role_name || 'User'}</span></p>
                <p><strong>Created By:</strong> ${u.created_by_name || 'System / Admin'}</p>
                <p><strong>Created:</strong> ${u.created_at ? new Date(u.created_at).toLocaleString() : 'N/A'}</p>
            </div>

            <div style="background:#F8FAFC; padding: 1.5rem; border-radius: 8px; border:1px solid #E2E8F0;">
                <h4 style="color:#1E293B; margin-bottom: 0.75rem; border-bottom: 1px solid #CBD5E1; padding-bottom: 8px;">🏠 Address Details</h4>
                <p><strong>Address:</strong> ${u.address || 'N/A'}</p>
                <p><strong>City:</strong> ${u.city || 'N/A'}</p>
                <p><strong>State:</strong> ${u.state || 'N/A'}</p>
                <p><strong>Pincode:</strong> ${u.pincode || 'N/A'}</p>
            </div>

            <div style="grid-column: span 2; background:#F8FAFC; padding: 1.5rem; border-radius: 8px; border:1px solid #E2E8F0;">
                <h4 style="color:#1E293B; margin-bottom: 0.75rem; border-bottom: 1px solid #CBD5E1; padding-bottom: 8px;">💳 Bank & Payment Details</h4>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                    <p><strong>Bank Name:</strong> ${u.bank_name || 'N/A'}</p>
                    <p><strong>Account No:</strong> ${u.account_no || 'N/A'}</p>
                    <p><strong>IFSC Code:</strong> ${u.ifsc_code || 'N/A'}</p>
                    <p><strong>UPI ID:</strong> ${u.upi_id || 'N/A'}</p>
                </div>
            </div>
        </div>
    `;

    modal.classList.add('active');
}

function closeModal() {
    const modal = document.getElementById('detailsModal');
    if (modal) modal.classList.remove('active');
}

// ==============================
// DELETE ITEM
// ==============================
async function deleteItem(endpoint, reloadFn) {
    if (!confirm('⚠️ Are you sure you want to delete this item?')) return;
    
    showLoading('Deleting...');
    try {
        await fetch(`${API_URL}${endpoint}`, {
            method: 'DELETE',
            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
        });
        hideLoading();
        reloadFn();
    } catch (error) {
        hideLoading();
        console.error('Delete error:', error);
        alert('Failed to delete item');
    }
}

// ==============================
// DOM READY
// ==============================
document.addEventListener("DOMContentLoaded", () => {
    // Show loading immediately
    showLoading('Initializing...');
    
    // Check authentication
    checkAuth();

    // Apply saved theme
    const savedTheme = localStorage.getItem("theme") || "light";
    applyTheme(savedTheme);

    const themeSelect = document.getElementById("settingTheme");
    if (themeSelect) {
        themeSelect.addEventListener("change", (e) => {
            applyTheme(e.target.value);
        });
    }

    // Close modal on overlay click
    const modal = document.getElementById('detailsModal');
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal();
            }
        });

        // Close on Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape') {
                closeModal();
            }
        });
    }

    // Safety timeout - hide loading after 10 seconds max
    setTimeout(() => {
        if (isLoading) {
            console.warn('Loading timeout - forcing hide');
            hideLoading();
        }
    }, 10000);
});

// ==============================
// WINDOW LOAD (Final safety)
// ==============================
window.addEventListener('load', () => {
    // Hide loading if still visible after page fully loads
    setTimeout(() => {
        if (isLoading) {
            hideLoading();
        }
    }, 1000);
});

// Export functions for inline onclick handlers
window.switchTab = switchTab;
window.logout = logout;
window.openDownlineModal = openDownlineModal;
window.openProfileModal = openProfileModal;
window.closeModal = closeModal;
window.deleteItem = deleteItem;
window.updateEnquiryStatus = updateEnquiryStatus;
window.loadUsers = loadUsers;
window.loadNews = loadNews;
window.loadEvents = loadEvents;
window.loadGallery = loadGallery;
window.loadBlogs = loadBlogs;
window.loadEnquiries = loadEnquiries;
window.loadMyProfile = loadMyProfile;

console.log('✅ Dashboard application loaded successfully');     